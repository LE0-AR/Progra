<?php
//Variables de entorno la url del archivo como el nombre
const APP_URL="http://localhost/DW/Biticarora/app";
const APP_NAME="INFOSEG";

?>