<?php
    header("Location: ./Admin");