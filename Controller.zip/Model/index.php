<?php
    require_once "../Controller/Config/Sesion.php";
    header("Location: ../");